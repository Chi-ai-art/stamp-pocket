export default {content:['./index.html','./src/**/*.{ts,tsx}'],theme:{extend:{colors:{paper:'#faf8f2',ink:'#303f38',leaf:'#38664f',peach:'#f2c3a6'}}},plugins:[]};
