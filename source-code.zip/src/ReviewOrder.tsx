import {useRef,useState} from 'react';
import type {ReactNode} from 'react';
import type {Sticker} from './data/types';
import {Grip,ChevronLeft,ChevronRight} from 'lucide-react';
export default function ReviewOrder({stickers,disabled,onMove,onEdit,render}:{stickers:Sticker[];disabled:boolean;onMove:(id:string,to:number)=>void;onEdit:(s:Sticker)=>void;render:(s:Sticker)=>ReactNode}){
 const drag=useRef<{id:string;target:number}|null>(null),[active,setActive]=useState(''),[over,setOver]=useState(-1),[message,setMessage]=useState('');
 function move(id:string,to:number){onMove(id,to);setMessage(`${to+1}番に移動しました`);}
 function cancel(){drag.current=null;setActive('');setOver(-1);}
 return <><p className="small">「並べ替え」を押したまま、好きな位置へスライド。番号順にZIPへ保存します。矢印や番号でも移動できます。</p><p className="small" role="status">{message}</p><div className="review-grid">{stickers.map((s,i)=><article key={s.id} data-order-id={s.id} data-order-index={i} className={'order-card '+(active===s.id?'order-active ':'')+(over===i?'order-over':'')}>
 <button disabled={disabled} className="review-item review-black" onClick={()=>onEdit(s)} aria-label={`${i+1}番の画像を調整`}>{render(s)}<span>{String(i+1).padStart(2,'0')}</span></button>
 <button disabled={disabled} className="order-handle" aria-label={`${i+1}番をドラッグして並べ替え`} onPointerDown={e=>{if(e.button!==0)return;e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);drag.current={id:s.id,target:i};setActive(s.id);setOver(i);}} onPointerMove={e=>{if(!drag.current)return;const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest<HTMLElement>('[data-order-index]');if(hit){const target=Number(hit.dataset.orderIndex);drag.current.target=target;setOver(target);}if(e.clientY<90)window.scrollBy(0,-18);else if(e.clientY>innerHeight-90)window.scrollBy(0,18);}} onPointerUp={()=>{const d=drag.current;if(d)move(d.id,d.target);cancel();}} onPointerCancel={cancel} onLostPointerCapture={cancel} onKeyDown={e=>{if(e.key==='Escape')cancel();}}><Grip size={16}/>並べ替え</button>
 <div className="order-controls"><button disabled={disabled||i===0} aria-label={`${i+1}番を前へ`} onClick={()=>move(s.id,i-1)}><ChevronLeft size={17}/></button><select disabled={disabled} aria-label={`${i+1}番の移動先`} value={i} onChange={e=>move(s.id,+e.target.value)}>{stickers.map((v,n)=><option key={v.id} value={n}>{n+1}番</option>)}</select><button disabled={disabled||i===stickers.length-1} aria-label={`${i+1}番を後ろへ`} onClick={()=>move(s.id,i+1)}><ChevronRight size={17}/></button></div></article>)}</div></>;
}
