// 背景透過エンジン。ブラウザ内だけで動く純粋関数（外部送信・APIなし）。
//
// 方針
//  1. 元から透過済みの画像は触らない。
//  2. 背景色は縁のリングから推定し、単色でなければ何もしない（絵を壊さない）。
//  3. 縁につながっている背景だけを塗りつぶす。囲まれた白い服・白い台紙は残る。
//  4. 輪郭の1〜3pxは「背景と前景の混色」とみなし、混ざり具合を解いて
//     半透明アルファ＋元の色に戻す。これで白フチとギザギザが同時に消える。
//     解けない画素（近くに確かな前景がない＝細い線、前景が背景と同色＝白い服、
//     混色として説明できない＝淡い飾り）は不透明のまま残す。
//  5. 背景に取り残された、ごく小さな背景色のかたまりだけを点として消す。

export type Rgb = [number, number, number];
export type CutoutReason = 'ok' | 'already-transparent' | 'no-uniform-background';
export interface CutoutReport {
  applied: boolean;
  reason: CutoutReason;
  background: Rgb | null;
  cleared: number;
  softened: number;
  specks: number;
}
export interface CutoutOptions {
  strength?: number; // 0-100。既定32。上げるほど広く背景とみなす
  matte?: boolean; // 輪郭の混色を解く（既定true）
  despeckle?: boolean; // 小さな点を消す（既定true）
  strong?: boolean; // 点の除去をやや強める
}

const clamp = (v: number, lo: number, hi: number) => (v < lo ? lo : v > hi ? hi : v);

/** アルファチャンネルの状態を調べる。 */
export function inspectAlpha(d: Uint8ClampedArray, w: number, h: number) {
  const n = w * h;
  let translucent = 0, borderClear = 0, border = 0;
  for (let p = 0; p < n; p++) {
    if (d[p * 4 + 3] < 250) translucent++;
    const x = p % w, y = (p / w) | 0;
    if (x < 2 || y < 2 || x >= w - 2 || y >= h - 2) { border++; if (d[p * 4 + 3] < 16) borderClear++; }
  }
  return { translucent: translucent / n, borderClear: border ? borderClear / border : 0 };
}

/** すでに透過済みとみなせるか。透過済みなら再処理しない。 */
export function alreadyTransparent(d: Uint8ClampedArray, w: number, h: number) {
  const s = inspectAlpha(d, w, h);
  return s.translucent > 0.3 || (s.translucent > 0.015 && s.borderClear > 0.35);
}

/** 縁のリングから背景色を推定する。単色でなければ uniformity が下がる。 */
export function estimateBackground(d: Uint8ClampedArray, w: number, h: number) {
  const px: number[] = [];
  const take = (p: number) => { if (d[p * 4 + 3] >= 200) px.push(p); };
  for (let x = 0; x < w; x++) for (let t = 0; t < 2 && t < h; t++) { take(t * w + x); take((h - 1 - t) * w + x); }
  for (let y = 0; y < h; y++) for (let t = 0; t < 2 && t < w; t++) { take(y * w + t); take(y * w + w - 1 - t); }
  if (px.length < 24) return null;
  const bg = [0, 1, 2].map(k => {
    const a = px.map(p => d[p * 4 + k]).sort((x, y) => x - y);
    return a[a.length >> 1];
  }) as Rgb;
  let near = 0;
  for (const p of px) {
    const i = p * 4;
    if (Math.max(Math.abs(d[i] - bg[0]), Math.abs(d[i + 1] - bg[1]), Math.abs(d[i + 2] - bg[2])) <= 16) near++;
  }
  return { bg, uniformity: near / px.length };
}

/** 半径 r 以内のオフセットを近い順に並べたもの（前景さがしに使う）。 */
function ringOffsets(r: number) {
  const out: { dx: number; dy: number; d2: number }[] = [];
  for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
    const d2 = dx * dx + dy * dy;
    if (d2 && d2 <= r * r) out.push({ dx, dy, d2 });
  }
  return out.sort((a, b) => a.d2 - b.d2);
}
const OFFSETS = ringOffsets(7);

/**
 * data を破壊的に書き換えて背景を透過する。
 * 何もしなかった場合は applied:false を返し、data は変更しない。
 */
export function cutout(d: Uint8ClampedArray, w: number, h: number, opts: CutoutOptions = {}): CutoutReport {
  const none = (reason: CutoutReason, background: Rgb | null = null): CutoutReport =>
    ({ applied: false, reason, background, cleared: 0, softened: 0, specks: 0 });
  const n = w * h;
  if (n < 16) return none('no-uniform-background');
  if (alreadyTransparent(d, w, h)) return none('already-transparent');
  const est = estimateBackground(d, w, h);
  if (!est || est.uniformity < 0.6) return none('no-uniform-background', est?.bg ?? null);

  const bg = est.bg;
  const strength = clamp(opts.strength ?? 32, 0, 100);
  const tol = Math.round(7 + strength * 0.32); // 既定 17
  const coreFg = Math.max(46, tol * 2 + 24); // ここまで違えば「確かな前景」

  // 背景からの距離（チャンネル最大差）
  const dist = new Uint8Array(n);
  for (let p = 0; p < n; p++) {
    const i = p * 4;
    dist[p] = Math.min(255, Math.max(Math.abs(d[i] - bg[0]), Math.abs(d[i + 1] - bg[1]), Math.abs(d[i + 2] - bg[2])));
  }

  // 1) 縁につながっている背景だけを塗る
  const mask = new Uint8Array(n); // 1 = 背景
  const queue = new Int32Array(n);
  let head = 0, tail = 0;
  const push = (p: number) => { if (!mask[p] && (d[p * 4 + 3] < 16 || dist[p] <= tol)) { mask[p] = 1; queue[tail++] = p; } };
  for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
  for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }
  while (head < tail) {
    const p = queue[head++], x = p % w;
    if (x > 0) push(p - 1);
    if (x < w - 1) push(p + 1);
    if (p >= w) push(p - w);
    if (p < n - w) push(p + w);
  }
  let cleared = 0;
  for (let p = 0; p < n; p++) if (mask[p] && d[p * 4 + 3]) cleared++;
  if (!cleared) return none('no-uniform-background', bg);
  // 絵まで消してしまう設定なら適用しない
  if (cleared > n * 0.995) return none('no-uniform-background', bg);

  // 2) 背景に取り残された、ごく小さな背景色のかたまり（白い点）を消す
  let specks = 0;
  if (opts.despeckle !== false) {
    const limit = Math.max(3, Math.round(n * 0.00006)) * (opts.strong ? 4 : 1);
    const seen = new Uint8Array(n), comp = new Int32Array(n);
    for (let s = 0; s < n; s++) {
      if (seen[s] || mask[s] || !d[s * 4 + 3]) continue;
      let ch = 0, ct = 1, peak = 0, over = false;
      comp[0] = s; seen[s] = 1;
      while (ch < ct) {
        const p = comp[ch++], x = p % w;
        if (dist[p] > peak) peak = dist[p];
        const add = (q: number) => {
          if (seen[q] || mask[q] || !d[q * 4 + 3]) return;
          seen[q] = 1;
          if (ct > limit) { over = true; return; }
          comp[ct++] = q;
        };
        if (x > 0) add(p - 1);
        if (x < w - 1) add(p + 1);
        if (p >= w) add(p - w);
        if (p < n - w) add(p + w);
        if (over) break;
      }
      if (over || ct > limit || peak >= 42) continue;
      for (let j = 0; j < ct; j++) { mask[comp[j]] = 1; specks++; }
    }
  }

  // 3) 背景を透明にする
  for (let p = 0; p < n; p++) if (mask[p]) d[p * 4 + 3] = 0;

  // 4) 輪郭の混色を解く（白フチとギザギザを同時に消す）
  let softened = 0;
  if (opts.matte !== false) {
    const R = 3;
    const band = new Uint8Array(n).fill(255);
    head = 0; tail = 0;
    for (let p = 0; p < n; p++) if (mask[p]) { band[p] = 0; queue[tail++] = p; }
    while (head < tail) {
      const p = queue[head++];
      if (band[p] >= R) continue;
      const x = p % w, nb = band[p] + 1;
      const step = (q: number) => { if (band[q] > nb) { band[q] = nb; queue[tail++] = q; } };
      if (x > 0) step(p - 1);
      if (x < w - 1) step(p + 1);
      if (p >= w) step(p - w);
      if (p < n - w) step(p + w);
    }
    const src = new Uint8ClampedArray(d); // 混色を解く前の色
    for (let p = 0; p < n; p++) {
      if (band[p] === 0 || band[p] > R) continue;
      const i = p * 4;
      if (!d[i + 3]) continue;
      const x = p % w, y = (p / w) | 0;
      // 近くの「確かな前景」を探す
      let f = -1;
      for (const o of OFFSETS) {
        const xx = x + o.dx, yy = y + o.dy;
        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
        const q = yy * w + xx;
        if (band[q] <= R || src[q * 4 + 3] < 250 || dist[q] < coreFg) continue;
        f = q; break;
      }
      if (f < 0) continue; // 細い線・小さな飾り → さわらない
      const j = f * 4;
      let den = 0, dot = 0;
      for (let k = 0; k < 3; k++) {
        const fb = src[j + k] - bg[k];
        den += fb * fb;
        dot += (src[i + k] - bg[k]) * fb;
      }
      if (den < 900) continue; // 前景が背景と同系色（白い服など）→ さわらない
      const a = clamp(dot / den, 0, 1);
      if (a > 0.965) continue;
      let residual = 0;
      for (let k = 0; k < 3; k++) residual = Math.max(residual, Math.abs(src[i + k] - (bg[k] + a * (src[j + k] - bg[k]))));
      if (residual > 26) continue; // 背景と前景の混色では説明できない色 → さわらない
      const na = Math.round(255 * a);
      if (na >= d[i + 3]) continue;
      d[i + 3] = na;
      softened++;
      if (a > 0.12) for (let k = 0; k < 3; k++) d[i + k] = clamp(Math.round((src[i + k] - bg[k] * (1 - a)) / a), 0, 255);
    }
  }
  return { applied: true, reason: 'ok', background: bg, cleared, softened, specks };
}

/**
 * すでに透過済みの画像から、輪郭に残った背景色のフチと点だけを整える。
 * 背景の推定には「透明の隣にある不透明画素」を使う。
 */
export function refineEdges(d: Uint8ClampedArray, w: number, h: number, strong = false): CutoutReport {
  const n = w * h;
  const s = inspectAlpha(d, w, h);
  if (s.translucent < 0.005) return { applied: false, reason: 'no-uniform-background', background: null, cleared: 0, softened: 0, specks: 0 };
  // 透明画素に隣接する不透明画素のうち、明るい方の色を「にじみ元」とみなす
  const edge: number[] = [];
  for (let p = 0; p < n; p++) {
    if (d[p * 4 + 3] < 250) continue;
    const x = p % w;
    const clearNear = (x > 0 && !d[(p - 1) * 4 + 3]) || (x < w - 1 && !d[(p + 1) * 4 + 3]) ||
      (p >= w && !d[(p - w) * 4 + 3]) || (p < n - w && !d[(p + w) * 4 + 3]);
    if (clearNear) edge.push(p);
  }
  if (edge.length < 24) return { applied: false, reason: 'no-uniform-background', background: null, cleared: 0, softened: 0, specks: 0 };
  const bg = [0, 1, 2].map(k => {
    const a = edge.map(p => d[p * 4 + k]).sort((x, y) => x - y);
    return a[Math.floor(a.length * 0.86)]; // 明るい側 = にじんだ背景色
  }) as Rgb;
  const lum = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2];
  // にじみ元が暗い場合は背景色を特定できていないので触らない
  if (lum < 120) return { applied: false, reason: 'no-uniform-background', background: bg, cleared: 0, softened: 0, specks: 0 };

  const dist = new Uint8Array(n);
  for (let p = 0; p < n; p++) {
    const i = p * 4;
    dist[p] = Math.min(255, Math.max(Math.abs(d[i] - bg[0]), Math.abs(d[i + 1] - bg[1]), Math.abs(d[i + 2] - bg[2])));
  }
  const mask = new Uint8Array(n);
  for (let p = 0; p < n; p++) if (!d[p * 4 + 3]) mask[p] = 1;

  // 透明のまわりに残った、背景色そのものの薄い輪（白フチ）を透明にする
  const tol = strong ? 20 : 13;
  const queue = new Int32Array(n);
  let head = 0, tail = 0, cleared = 0;
  for (const p of edge) if (dist[p] <= tol) { mask[p] = 1; queue[tail++] = p; cleared++; }
  while (head < tail) {
    const p = queue[head++], x = p % w;
    const step = (q: number) => { if (!mask[q] && d[q * 4 + 3] >= 250 && dist[q] <= tol) { mask[q] = 1; queue[tail++] = q; cleared++; } };
    if (x > 0) step(p - 1);
    if (x < w - 1) step(p + 1);
    if (p >= w) step(p - w);
    if (p < n - w) step(p + w);
  }
  for (let p = 0; p < n; p++) if (mask[p]) d[p * 4 + 3] = 0;

  // 小さな点
  let specks = 0;
  const limit = Math.max(3, Math.round(n * 0.00006)) * (strong ? 4 : 1);
  const seen = new Uint8Array(n), comp = new Int32Array(n);
  for (let s2 = 0; s2 < n; s2++) {
    if (seen[s2] || mask[s2] || !d[s2 * 4 + 3]) continue;
    let ch = 0, ct = 1, peak = 0, over = false;
    comp[0] = s2; seen[s2] = 1;
    while (ch < ct) {
      const p = comp[ch++], x = p % w;
      if (dist[p] > peak) peak = dist[p];
      const add = (q: number) => {
        if (seen[q] || mask[q] || !d[q * 4 + 3]) return;
        seen[q] = 1;
        if (ct > limit) { over = true; return; }
        comp[ct++] = q;
      };
      if (x > 0) add(p - 1);
      if (x < w - 1) add(p + 1);
      if (p >= w) add(p - w);
      if (p < n - w) add(p + w);
      if (over) break;
    }
    if (over || ct > limit || peak >= 42) continue;
    for (let j = 0; j < ct; j++) { d[comp[j] * 4 + 3] = 0; mask[comp[j]] = 1; specks++; }
  }

  // 残った輪郭の混色を解く
  const coreFg = 46;
  const R = 2;
  const band = new Uint8Array(n).fill(255);
  head = 0; tail = 0;
  for (let p = 0; p < n; p++) if (mask[p]) { band[p] = 0; queue[tail++] = p; }
  while (head < tail) {
    const p = queue[head++];
    if (band[p] >= R) continue;
    const x = p % w, nb = band[p] + 1;
    const step = (q: number) => { if (band[q] > nb) { band[q] = nb; queue[tail++] = q; } };
    if (x > 0) step(p - 1);
    if (x < w - 1) step(p + 1);
    if (p >= w) step(p - w);
    if (p < n - w) step(p + w);
  }
  const src = new Uint8ClampedArray(d);
  let softened = 0;
  for (let p = 0; p < n; p++) {
    if (band[p] === 0 || band[p] > R) continue;
    const i = p * 4;
    if (d[i + 3] < 250) continue;
    const x = p % w, y = (p / w) | 0;
    let f = -1;
    for (const o of OFFSETS) {
      const xx = x + o.dx, yy = y + o.dy;
      if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
      const q = yy * w + xx;
      if (band[q] <= R || src[q * 4 + 3] < 250 || dist[q] < coreFg) continue;
      f = q; break;
    }
    if (f < 0) continue;
    const j = f * 4;
    let den = 0, dot = 0;
    for (let k = 0; k < 3; k++) { const fb = src[j + k] - bg[k]; den += fb * fb; dot += (src[i + k] - bg[k]) * fb; }
    if (den < 900) continue;
    const a = clamp(dot / den, 0, 1);
    if (a > 0.965) continue;
    let residual = 0;
    for (let k = 0; k < 3; k++) residual = Math.max(residual, Math.abs(src[i + k] - (bg[k] + a * (src[j + k] - bg[k]))));
    if (residual > 26) continue;
    d[i + 3] = Math.round(255 * a);
    softened++;
    if (a > 0.12) for (let k = 0; k < 3; k++) d[i + k] = clamp(Math.round((src[i + k] - bg[k] * (1 - a)) / a), 0, 255);
  }
  return { applied: cleared + specks + softened > 0, reason: 'ok', background: bg, cleared, softened, specks };
}
