import {canvas,loadImage} from './imaging';
// Flood only the chosen background component and matching border-connected pixels.
// Existing alpha and enclosed foreground regions remain intact.
export async function removeBackground(src:string,color:string,tolerance:number,seed?:{x:number;y:number}){
 const im=await loadImage(src),c=canvas(im.width,im.height),ctx=c.getContext('2d')!;ctx.drawImage(im,0,0);
 const frame=ctx.getImageData(0,0,c.width,c.height),d=frame.data,w=c.width,h=c.height,n=w*h;
 const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16));
 const seen=new Uint8Array(n),queue=new Int32Array(n);let head=0,tail=0,removed=0;
 const distance=(p:number)=>Math.max(...rgb.map((v,k)=>Math.abs(d[p*4+k]-v)));
 const add=(p:number)=>{if(seen[p])return;seen[p]=1;if(d[p*4+3]===0||distance(p)<=tolerance){queue[tail++]=p;}};
 for(let x=0;x<w;x++){add(x);add((h-1)*w+x);}for(let y=0;y<h;y++){add(y*w);add(y*w+w-1);}
 if(seed)add(Math.min(h-1,Math.max(0,Math.floor(seed.y*h)))*w+Math.min(w-1,Math.max(0,Math.floor(seed.x*w))));
 while(head<tail){const p=queue[head++];if(d[p*4+3])removed++;d[p*4+3]=0;const x=p%w;if(x>0)add(p-1);if(x<w-1)add(p+1);if(p>=w)add(p-w);if(p<n-w)add(p+w);if(head%100000===0)await new Promise(r=>setTimeout(r,0));}
 if(!removed)throw new Error('消せる背景が見つかりませんでした。背景をタップして色を選び直してください。');
 if(!d.some((v,i)=>i%4===3&&v>8))throw new Error('画像全体が消えるため適用しませんでした。強さを下げてください。');
 ctx.putImageData(frame,0,0);return c.toDataURL('image/png');
}
