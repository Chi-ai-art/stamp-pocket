import {canvas,loadImage} from './imaging';
export async function detectBackground(src:string){
 const im=await loadImage(src),c=canvas(im.width,im.height),ctx=c.getContext('2d')!;ctx.drawImage(im,0,0);const d=ctx.getImageData(0,0,c.width,c.height).data;
 const bins=new Map<string,number[][]>();
 const sample=(x:number,y:number)=>{const p=(y*c.width+x)*4;if(d[p+3]<240)return;const rgb=[d[p],d[p+1],d[p+2]],key=rgb.map(v=>Math.floor(v/16)).join(',');const list=bins.get(key)??[];list.push(rgb);bins.set(key,list);};
 for(let i=0;i<128;i++){const x=Math.round(i*(c.width-1)/127),y=Math.round(i*(c.height-1)/127);sample(x,0);sample(x,c.height-1);sample(0,y);sample(c.width-1,y);}
 const group=[...bins.values()].sort((a,b)=>b.length-a.length)[0];if(!group||group.length<32)throw new Error('外側の背景色を見つけられませんでした。背景をタップして色を選んでください。');
 return '#'+[0,1,2].map(k=>group.map(v=>v[k]).sort((a,b)=>a-b)[Math.floor(group.length/2)].toString(16).padStart(2,'0')).join('');
}
// Flood only the chosen background component and matching border-connected pixels.
// Existing alpha and enclosed foreground regions remain intact.
export async function removeBackground(src:string,color:string,tolerance:number,seed?:{x:number;y:number},protectWhite=true){
 const im=await loadImage(src),c=canvas(im.width,im.height),ctx=c.getContext('2d')!;ctx.drawImage(im,0,0);
 const frame=ctx.getImageData(0,0,c.width,c.height),d=frame.data,w=c.width,h=c.height,n=w*h;
 const rgb=[1,3,5].map(i=>parseInt(color.slice(i,i+2),16));
 const whiteDistance=Math.max(...rgb.map(v=>255-v));
 // Beige backgrounds must never share the broad white-removal threshold.
 const limit=protectWhite&&whiteDistance>10?Math.min(tolerance,whiteDistance*.45):tolerance;
 const seen=new Uint8Array(n),queue=new Int32Array(n);let head=0,tail=0,removed=0;
 const distance=(p:number)=>Math.max(...rgb.map((v,k)=>Math.abs(d[p*4+k]-v)));
 const add=(p:number)=>{if(seen[p])return;seen[p]=1;if(d[p*4+3]===0||distance(p)<=limit){queue[tail++]=p;}};
 for(let x=0;x<w;x++){add(x);add((h-1)*w+x);}for(let y=0;y<h;y++){add(y*w);add(y*w+w-1);}
 if(seed)add(Math.min(h-1,Math.max(0,Math.floor(seed.y*h)))*w+Math.min(w-1,Math.max(0,Math.floor(seed.x*w))));
 while(head<tail){const p=queue[head++];if(d[p*4+3])removed++;d[p*4+3]=0;const x=p%w;if(x>0)add(p-1);if(x<w-1)add(p+1);if(p>=w)add(p-w);if(p<n-w)add(p+w);if(head%100000===0)await new Promise(r=>setTimeout(r,0));}
 if(!removed)throw new Error('消せる背景が見つかりませんでした。背景をタップして色を選び直してください。');
 if(!d.some((v,i)=>i%4===3&&v>8))throw new Error('画像全体が消えるため適用しませんでした。強さを下げてください。');
 // Remove isolated JPEG flecks (up to four pixels), then soften only the outside edge.
 const visited=new Uint8Array(n);
 for(let start=0;start<n;start++){if(!d[start*4+3]||visited[start])continue;let a=0,b=1;queue[0]=start;visited[start]=1;
 while(a<b){const p=queue[a++],x=p%w;for(const q of [x>0?p-1:-1,x<w-1?p+1:-1,p>=w?p-w:-1,p<n-w?p+w:-1])if(q>=0&&!visited[q]&&d[q*4+3]){visited[q]=1;queue[b++]=q;}if(a%100000===0)await new Promise(r=>setTimeout(r,0));}
 if(b<=4)for(let i=0;i<b;i++)d[queue[i]*4+3]=0;
 }
 const alpha=new Uint8Array(n);for(let p=0;p<n;p++)alpha[p]=d[p*4+3];
 for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){const p=y*w+x;if(!alpha[p])continue;let coverage=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)coverage+=alpha[p+dy*w+dx]*(dx===0?2:1)*(dy===0?2:1);d[p*4+3]=Math.min(alpha[p],Math.round(coverage/16));}
 ctx.putImageData(frame,0,0);return c.toDataURL('image/png');
}
