import {detectBackground,removeBackground} from './removeBackground';
import {removeWhiteOutlineBackground} from './removeWhiteOutlineBackground';
import TransparencyFinish from './TransparencyFinish';
import type {TransparencyMode} from './TransparencyFinish';
import {useScrollLock} from './useScrollLock';
import {useEffect,useRef,useState} from 'react';
import {X,Scissors,ArrowRight} from 'lucide-react';
import type {Sheet,Sticker} from './data/types';
import {splitSheet,suggestCuts} from './imaging';
const even=(n:number)=>Array.from({length:n+1},(_,i)=>i/n);
export default function SheetDialog({sheet,onDone,onClose}:{sheet:Sheet;onDone:(s:Sticker[])=>void;onClose:()=>void}){
 const operation=useRef<AbortController|null>(null);
 useEffect(()=>()=>{operation.current?.abort();},[]);
 function close(){operation.current?.abort();operation.current=null;onClose();}
 const[image,setImage]=useState(sheet.src),[removing,setRemoving]=useState(false),[notice,setNotice]=useState('');
 const[finish,setFinish]=useState<TransparencyMode>('normal'),[outlineWidth,setOutlineWidth]=useState(Math.max(2,Math.min(12,Math.round(Math.max(sheet.width,sheet.height)/256))));
 function resetPreview(){setImage(sheet.src);setNotice('設定を変更しました。「透過する！」で仕上がりを確認してください。');setError('');}
 const[cols,setCols]=useState(4),[rows,setRows]=useState(4),[xs,setXs]=useState(even(4)),[ys,setYs]=useState(even(4)),[progress,setProgress]=useState<number|null>(null),[error,setError]=useState(''),[detecting,setDetecting]=useState(true);const drag=useRef<{axis:'x'|'y';index:number}|null>(null);
 useEffect(()=>{let alive=true;setDetecting(true);suggestCuts(sheet.src,cols,rows).then(v=>{if(alive){setXs(v.xs);setYs(v.ys);}}).catch(()=>{}).finally(()=>{if(alive)setDetecting(false);});return()=>{alive=false;};},[sheet.src,cols,rows]);
 useScrollLock();
 async function transparent(){
  if(operation.current)return;const controller=new AbortController();operation.current=controller;
  setRemoving(true);setError('');setNotice('');
  try{await new Promise(r=>setTimeout(r,0));if(controller.signal.aborted)return;
   const result=finish==='outline'?await removeWhiteOutlineBackground(sheet.src,outlineWidth,controller.signal):await removeBackground(sheet.src,await detectBackground(sheet.src),8,undefined,true,true,controller.signal);
   if(controller.signal.aborted)return;setImage(result);setNotice('透過しました。仕上がりを確認してください。');
  }catch(e){if(!controller.signal.aborted)setError((e as Error).message);}
  finally{if(operation.current===controller){operation.current=null;setRemoving(false);}}
 }
 async function run(){
  if(detecting||operation.current)return;const controller=new AbortController();operation.current=controller;
  setProgress(0);setError('');
  try{const s=await splitSheet(image,xs,ys,p=>{if(!controller.signal.aborted)setProgress(p*(image===sheet.src?1:.5));},controller.signal);
   if(image!==sheet.src){const originals=await splitSheet(sheet.src,xs,ys,p=>{if(!controller.signal.aborted)setProgress(.5+p*.5);},controller.signal);s.forEach((v,i)=>v.original=originals[i].image);}
   if(!controller.signal.aborted)onDone(s);
  }catch(e){if(!controller.signal.aborted)setError((e as Error).message);}
  finally{if(operation.current===controller){operation.current=null;setProgress(null);}}
 }
 return <div className="modal-backdrop"><section className="sheet-dialog modal" role="dialog" aria-modal="true" aria-label="切り抜く位置を確認" onKeyDown={e=>{if(e.key==='Escape'){e.stopPropagation();close();}if(e.key==='Tab'){const ns=Array.from(e.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled]),select:not([disabled])'));if(e.shiftKey&&document.activeElement===ns[0]){e.preventDefault();ns[ns.length-1]?.focus();}else if(!e.shiftKey&&document.activeElement===ns[ns.length-1]){e.preventDefault();ns[0]?.focus();}}}}><header className="modal-head"><div><span className="eyebrow">切る前に、ひと確認</span><h2>並び方を合わせましょう</h2></div><button autoFocus className="icon-btn" onClick={close} aria-label="画像の追加を中止"><X/></button></header><div className="sheet-body"><p>線が絵に重なっていないか確認してください。<br/>線を指で動かして、切り抜く位置を調整できます。</p><div className="grid-controls"><label>横の個数<select disabled={progress!==null||removing} aria-label="横の個数" value={cols} onChange={e=>{setCols(+e.target.value);setXs(even(+e.target.value));}}>{Array.from({length:8},(_,i)=><option key={i} value={i+1}>{i+1} 列</option>)}</select></label><span>×</span><label>縦の個数<select disabled={progress!==null||removing} aria-label="縦の個数" value={rows} onChange={e=>{setRows(+e.target.value);setYs(even(+e.target.value));}}>{Array.from({length:8},(_,i)=><option key={i} value={i+1}>{i+1} 行</option>)}</select></label><strong>{cols*rows} 個</strong></div>
 <TransparencyFinish mode={finish} width={outlineWidth} disabled={removing||progress!==null} onMode={mode=>{setFinish(mode);resetPreview();}} onWidth={width=>{setOutlineWidth(width);resetPreview();}}/>
 <div className="sheet-transparency"><button className="secondary transparency-action" disabled={removing||progress!==null||image!==sheet.src} onClick={()=>void transparent()}>{removing?'透過しています…':image!==sheet.src?'透過しました':'透過する！'}</button>{image!==sheet.src&&<button className="text-button" disabled={removing||progress!==null} onClick={()=>{setImage(sheet.src);setNotice('元の画像に戻しました。');setError('');}}>元に戻す</button>}<p className="small" role="status">{notice}</p></div>
 <div className={'sheet-preview '+(image!==sheet.src?'sheet-transparent':'')} aria-busy={removing}><img src={image} alt="切り抜き線を重ねた一覧画像"/><svg viewBox="0 0 1000 1000" preserveAspectRatio="none" onPointerMove={e=>{if(!drag.current||progress!==null||removing)return;const r=e.currentTarget.getBoundingClientRect(),{axis,index}=drag.current;const v=axis==='x'?(e.clientX-r.left)/r.width:(e.clientY-r.top)/r.height;const a=[...(axis==='x'?xs:ys)];a[index]=Math.max(a[index-1]+.02,Math.min(a[index+1]-.02,v));(axis==='x'?setXs:setYs)(a);}} onPointerUp={()=>drag.current=null} onPointerCancel={()=>drag.current=null}>
 {(['x','y'] as const).flatMap(axis=>(axis==='x'?xs:ys).slice(1,-1).map((v,i)=><g key={axis+i} onPointerDown={e=>{if(progress!==null||removing)return;drag.current={axis,index:i+1};e.currentTarget.ownerSVGElement!.setPointerCapture(e.pointerId);}}><line className="grid-hit" x1={axis==='x'?v*1000:0} x2={axis==='x'?v*1000:1000} y1={axis==='y'?v*1000:0} y2={axis==='y'?v*1000:1000}/><line className="grid-line" x1={axis==='x'?v*1000:0} x2={axis==='x'?v*1000:1000} y1={axis==='y'?v*1000:0} y2={axis==='y'?v*1000:1000}/></g>))}</svg></div>
 <p className="small">透明部分はそのまま保持します。細かい調整は、切り抜き後の「位置・大きさ・透過」でできます。市松模様や写真の背景は対象外です。</p>{error&&<p role="alert" className="error">{error}</p>}{progress!==null&&<div role="status"><p>1枚ずつ仕上げています… {Math.round(progress*100)}%</p><progress value={progress} max="1"/></div>}</div><footer className="modal-foot"><span className="small" role="status">{progress!==null?`切り抜き中… ${Math.round(progress*100)}%（×で中止できます）`:removing?'透過中…（×で中止できます）':'元の画像は残ります'}</span><button className="primary" disabled={progress!==null||detecting||removing} onClick={run}><Scissors size={18}/>{cols*rows}個に切り抜く<ArrowRight size={17}/></button></footer></section></div>;
}


