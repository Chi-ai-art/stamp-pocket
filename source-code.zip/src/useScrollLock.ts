import {useEffect} from 'react';
let locks=0;
let original='';
export function useScrollLock(){
 useEffect(()=>{
  if(locks===0){original=document.body.style.overflow;document.body.style.overflow='hidden';}
  locks++;
  return()=>{locks--;if(locks===0)document.body.style.overflow=original;};
 },[]);
}
