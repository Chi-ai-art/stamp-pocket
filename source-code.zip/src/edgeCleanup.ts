// Opt-in white-matte cleanup. Never changes opaque interior pixels or grows alpha.
export function cleanWhiteEdges(input:Uint8ClampedArray,w:number,h:number,strong=false){
 const out=new Uint8ClampedArray(input),n=w*h,seen=new Uint8Array(n),queue=new Int32Array(n);
 const nearWhite=(p:number)=>{const i=p*4;return Math.min(input[i],input[i+1],input[i+2])>210&&Math.max(input[i],input[i+1],input[i+2])-Math.min(input[i],input[i+1],input[i+2])<22;};
 const neighbors=(p:number,fn:(q:number)=>void)=>{const x=p%w;if(x)fn(p-1);if(x<w-1)fn(p+1);if(p>=w)fn(p-w);if(p<n-w)fn(p+w);};
 // Remove only tiny, isolated, neutral-white components. Colored decoration survives.
 for(let p=0;p<n;p++){if(seen[p]||!input[p*4+3])continue;let head=0,tail=1,white=true;queue[0]=p;seen[p]=1;
  while(head<tail){const q=queue[head++];white=white&&nearWhite(q);neighbors(q,r=>{if(!seen[r]&&input[r*4+3]){seen[r]=1;queue[tail++]=r;}});}
  if(white&&tail<=(strong?64:24))for(let j=0;j<tail;j++)out[queue[j]*4+3]=0;
 }
 const radius=strong?3:2,dist=new Uint8Array(n);dist.fill(255);let head=0,tail=0;
 for(let p=0;p<n;p++)if(out[p*4+3]===0){dist[p]=0;queue[tail++]=p;}
 while(head<tail){const p=queue[head++];if(dist[p]>=radius+2)continue;neighbors(p,q=>{if(dist[q]>dist[p]+1){dist[q]=dist[p]+1;queue[tail++]=q;}});}
 for(let p=0;p<n;p++){
  const i=p*4;if(!out[i+3]||dist[p]>radius)continue;
  const x=p%w,y=Math.floor(p/w);let best=-1,cost=Infinity;
  for(let dy=-radius-2;dy<=radius+2;dy++)for(let dx=-radius-2;dx<=radius+2;dx++){
   const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=w||yy>=h)continue;const q=yy*w+xx,j=q*4;
   if(dist[q]<=radius||input[j+3]<250)continue;
   const contrast=255-Math.min(input[j],input[j+1],input[j+2]);if(contrast<45)continue;
   const c=dx*dx+dy*dy;if(c<cost){cost=c;best=q;}
  }
  if(best<0)continue;const j=best*4;
  let dot=0,den=0;for(let k=0;k<3;k++){dot+=(255-input[i+k])*(255-input[j+k]);den+=(255-input[j+k])**2;}
  const a=Math.max(0,Math.min(1,dot/den));if(a>.96)continue;
  let error=0;for(let k=0;k<3;k++)error=Math.max(error,Math.abs(input[i+k]-(255+a*(input[j+k]-255))));
  if(error>(strong?22:14))continue;
  out[i+3]=Math.round(out[i+3]*a);if(a>.025)for(let k=0;k<3;k++)out[i+k]=Math.max(0,Math.min(255,Math.round((input[i+k]-255*(1-a))/a)));
 }
 return out;
}

