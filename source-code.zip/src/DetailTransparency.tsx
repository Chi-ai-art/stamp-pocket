import {useRef,useState} from 'react';
import {eraseConnected} from './eraseConnected';

export default function DetailTransparency({value,onApply,onCancel}:{value:string;onApply:(image:string)=>void;onCancel:()=>void}){
 const[image,setImage]=useState(value),[history,setHistory]=useState<string[]>([]),[zoom,setZoom]=useState(100),[strength,setStrength]=useState(16),[busy,setBusy]=useState(false),[message,setMessage]=useState('消したい部分を拡大してタップしてください。');
 const lock=useRef(false),down=useRef<{x:number;y:number;left:number;top:number}|null>(null),viewport=useRef<HTMLDivElement>(null);
 async function erase(x:number,y:number){if(lock.current)return;lock.current=true;setBusy(true);try{const next=await eraseConnected(image,x,y,strength);setHistory(old=>[...old.slice(-9),image]);setImage(next);setMessage('タップした部分を透過しました。違うところが消えたら「ひとつ戻す」で戻せます。');}catch(e){setMessage((e as Error).message);}finally{lock.current=false;setBusy(false);}}
 return <><div className="detail-transparency editor-scroll">
 <h3>ここだけ透過</h3><p className="small">同じ色でつながった部分だけ消します。拡大後は画像を指で動かせます。</p>
 <label className="range-label">拡大 {zoom}%<input aria-label="画像の拡大率" type="range" min="100" max="400" step="25" value={zoom} disabled={busy} onChange={e=>setZoom(+e.target.value)}/></label>
 <label className="range-label">消す強さ {strength}<input aria-label="ここだけ透過の強さ" type="range" min="2" max="60" value={strength} disabled={busy} onChange={e=>setStrength(+e.target.value)}/></label>
 <div className="detail-actions"><button className="secondary" disabled={busy||!history.length} onClick={()=>{setImage(history[history.length-1]);setHistory(h=>h.slice(0,-1));setMessage('ひとつ前に戻しました。');}}>ひとつ戻す</button><button className="text-button" disabled={busy||image===value} onClick={()=>{setHistory(h=>[...h.slice(-9),image]);setImage(value);setMessage('この仕上げを始める前に戻しました。');}}>仕上げ前に戻す</button></div>
 <p className="small" role="status" aria-live="polite">{busy?'透過しています…':message}</p>
 <div ref={viewport} className="detail-viewport"><img src={image} alt="ここだけ透過する画像。拡大して消したい部分をタップ" draggable={false} style={{width:`${zoom}%`}} onPointerDown={e=>{if(!e.isPrimary||busy)return;down.current={x:e.clientX,y:e.clientY,left:viewport.current?.scrollLeft??0,top:viewport.current?.scrollTop??0};}} onPointerCancel={()=>{down.current=null;}} onPointerUp={e=>{const p=down.current;down.current=null;if(!p||busy||!e.isPrimary||Math.hypot(e.clientX-p.x,e.clientY-p.y)>8||Math.abs((viewport.current?.scrollLeft??0)-p.left)>2||Math.abs((viewport.current?.scrollTop??0)-p.top)>2)return;const r=e.currentTarget.getBoundingClientRect();void erase((e.clientX-r.left)/r.width,(e.clientY-r.top)/r.height);}}/></div>
 <p className="small">消し残りは少しずつ強さを上げて調整できます。戻せるのは直近10回です。</p>
 </div><footer className="modal-foot"><button className="secondary" disabled={busy} onClick={onCancel}>変更せず戻る</button><button className="primary" disabled={busy} onClick={()=>onApply(image)}>この仕上げを使う</button></footer></>;
}
