import {canvas,loadImage} from './imaging';

// Only the tapped component is changed. Existing transparency is a boundary.
export async function eraseConnected(src:string,x:number,y:number,tolerance:number){
 const im=await loadImage(src),c=canvas(im.width,im.height),ctx=c.getContext('2d')!;
 ctx.drawImage(im,0,0);const frame=ctx.getImageData(0,0,c.width,c.height),d=frame.data,w=c.width,h=c.height;
 const px=Math.min(w-1,Math.max(0,Math.floor(x*w))),py=Math.min(h-1,Math.max(0,Math.floor(y*h))),start=py*w+px;
 if(!d[start*4+3])throw new Error('ここはすでに透明です。白く残っているところをタップしてください。');
 const rgb=[d[start*4],d[start*4+1],d[start*4+2]],seen=new Uint8Array(w*h),queue=new Int32Array(w*h);
 let head=0,tail=0;
 const add=(p:number)=>{if(seen[p])return;seen[p]=1;const i=p*4;if(d[i+3]&&Math.max(Math.abs(d[i]-rgb[0]),Math.abs(d[i+1]-rgb[1]),Math.abs(d[i+2]-rgb[2]))<=tolerance)queue[tail++]=p;};
 add(start);
 while(head<tail){const p=queue[head++],xx=p%w;d[p*4+3]=0;if(xx>0)add(p-1);if(xx<w-1)add(p+1);if(p>=w)add(p-w);if(p<w*(h-1))add(p+w);if(head%50000===0)await new Promise(r=>setTimeout(r,0));}
 if(!d.some((v,i)=>i%4===3&&v>0))throw new Error('画像全体が消えるため変更しませんでした。消す強さを下げてください。');
 ctx.putImageData(frame,0,0);return c.toDataURL('image/png');
}
