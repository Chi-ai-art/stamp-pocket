import ClearImages from './ClearImages';
import {useScrollLock} from './useScrollLock';
import {useEffect,useState} from 'react';
import {Check,Move,RotateCcw,X} from 'lucide-react';
import type {Sticker} from './data/types';

export default function CutSelection({stickers,onEdit,onDone,onBack,onDelete}:{stickers:Sticker[];onDelete:(ids:string[])=>void;onEdit:(sticker:Sticker)=>void;onDone:(stickers:Sticker[])=>void;onBack:()=>void}){
 const[selected,setSelected]=useState<Set<string>>(()=>new Set());
 useScrollLock();
 const toggle=(id:string)=>setSelected(old=>{const next=new Set(old);next.has(id)?next.delete(id):next.add(id);return next;});
 const picked=stickers.filter(sticker=>selected.has(sticker.id));
 return <div className="modal-backdrop cut-selection-backdrop"><section className="modal cut-selection" role="dialog" aria-modal="true" aria-labelledby="cut-selection-title">
  <header className="modal-head"><div><span className="eyebrow">カットできました</span><h2 id="cut-selection-title">残す画像を選びましょう</h2><p>必要な画像だけチェックしてください。ストックへ入れる前に、位置や大きさも調整できます。</p></div><button className="icon-btn" onClick={onBack} aria-label="切り分け画面に戻る"><X/></button></header>
  <div className="cut-selection-tools"><strong><span>{selected.size}</span> / {stickers.length}枚を選択</strong><div><button className="text-button" onClick={()=>setSelected(new Set(stickers.map(s=>s.id)))} disabled={selected.size===stickers.length}>すべて選択</button><button className="text-button" onClick={()=>setSelected(new Set())} disabled={!selected.size}>選択を外す</button></div></div>
  <ClearImages stickers={stickers} onDelete={ids=>{if(window.confirm(ids.length+'枚の切り抜きをクリアしますか？')){onDelete(ids);setSelected(old=>new Set([...old].filter(id=>!ids.includes(id))));}}}/>
  <div className="cut-selection-grid">
   {stickers.map((sticker,index)=>{const isSelected=selected.has(sticker.id);return <article key={sticker.id} className={'cut-choice '+(isSelected?'is-selected':'')}>
    <button className="cut-choice-pick" aria-pressed={isSelected} aria-label={`${index+1}番を${isSelected?'選択から外す':'残す画像に選ぶ'}`} onClick={()=>toggle(sticker.id)}>
     <span className="cut-choice-check">{isSelected?<Check size={18}/>:null}</span><span className="cut-choice-number">{String(index+1).padStart(2,'0')}</span><img src={sticker.image} alt={`${index+1}番の切り抜き`}/>
    </button>
    <button className="cut-choice-edit" onClick={()=>onEdit(sticker)}><Move size={15}/>位置・大きさを調整</button>
   </article>;})}
  </div>
  <footer className="modal-foot cut-selection-foot"><button className="secondary" onClick={onBack}><RotateCcw size={16}/>切り分けに戻る</button><button className="primary" disabled={!picked.length} onClick={()=>onDone(picked)}><Check size={18}/>選んだ{picked.length}枚をストックへ</button></footer>
 </section></div>;
}
