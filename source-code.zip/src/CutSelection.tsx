import {useScrollLock} from './useScrollLock';
import {useState} from 'react';
import {Check,Move,RotateCcw,X} from 'lucide-react';
import type {Sticker} from './data/types';

export default function CutSelection({stickers,onEdit,onDone,onBack,onDelete}:{stickers:Sticker[];onDelete:(ids:string[])=>void;onEdit:(sticker:Sticker)=>void;onDone:(stickers:Sticker[])=>void;onBack:()=>void}){
 const[selected,setSelected]=useState<Set<string>>(()=>new Set());
 useScrollLock();
 const toggle=(id:string)=>setSelected(old=>{const next=new Set(old);next.has(id)?next.delete(id):next.add(id);return next;});
 const picked=stickers.filter(sticker=>selected.has(sticker.id));
 return <div className="modal-backdrop cut-selection-backdrop"><section className="modal cut-selection" role="dialog" aria-modal="true" aria-labelledby="cut-selection-title">
  <header className="modal-head"><div><span className="eyebrow">カットできました</span><h2 id="cut-selection-title">キープする画像を選びましょう</h2><p>残したい画像をチェックしてください。位置や大きさも調整できます。今回のセットに使う画像は、キープした後に選びます。</p></div><button className="icon-btn" onClick={onBack} aria-label="切り分け画面に戻る"><X/></button></header>
  <div className="cut-selection-tools"><strong><span>{selected.size}</span> / {stickers.length}枚を選択</strong></div>
  <div className="cut-selection-actions"><button className="cut-clear-all" disabled={!stickers.length} onClick={()=>{if(window.confirm(stickers.length+'枚の切り抜きをクリアしますか？')){onDelete(stickers.map(s=>s.id));setSelected(new Set());}}}>全部まとめてクリア</button><button className="cut-select-all" disabled={!stickers.length||selected.size===stickers.length} onClick={()=>setSelected(new Set(stickers.map(s=>s.id)))}>すべて選択</button></div>
  <div className="cut-selection-grid">
   {stickers.map((sticker,index)=>{const isSelected=selected.has(sticker.id);return <article key={sticker.id} className={'cut-choice '+(isSelected?'is-selected':'')}>
    <button className="cut-choice-pick" aria-pressed={isSelected} aria-label={`${index+1}番を${isSelected?'選択から外す':'残す画像に選ぶ'}`} onClick={()=>toggle(sticker.id)}>
     <span className="cut-choice-check">{isSelected?<Check size={18}/>:null}</span><span className="cut-choice-number">{String(index+1).padStart(2,'0')}</span><img src={sticker.image} alt={`${index+1}番の切り抜き`}/>
    </button>
    <button className="cut-choice-edit" onClick={()=>onEdit(sticker)}><Move size={15}/>位置・大きさを調整</button>
   </article>;})}
  </div>
  <footer className="modal-foot cut-selection-foot"><button className="secondary" onClick={onBack}><RotateCcw size={16}/>切り分けに戻る</button><button className="primary" disabled={!picked.length} onClick={()=>onDone(picked)}><Check size={18}/>選んだ{picked.length}枚をキープへ</button></footer>
 </section></div>;
}
