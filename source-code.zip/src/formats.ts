export type ProductKind='sticker'|'emoji';
export const formats={
 sticker:{label:'LINEスタンプ',noun:'スタンプ',counts:[8,16,24,32,40],width:370,height:320,margin:10,digits:2,main:true,zipMB:60,source:'https://creator.line.me/ja/guideline/sticker/'},
 emoji:{label:'LINE絵文字',noun:'絵文字',counts:[...Array.from({length:33},(_,i)=>i+8),104,...Array.from({length:33},(_,i)=>i+112),161,...Array.from({length:33},(_,i)=>i+169),265,...Array.from({length:33},(_,i)=>i+273)],width:180,height:180,margin:0,digits:3,main:false,zipMB:20,source:'https://creator.line.me/ja/guideline/emoji/'}
} as const;
export const validCount=(kind:ProductKind,n:number)=>(formats[kind].counts as readonly number[]).includes(n);

export const kanaCharacters=Array.from('あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんぁぃぅぇぉっゃゅょがぎぐげござじずぜぞだぢづでどばびぶべぼぱぴぷぺぽア イ ウ エ オ カ キ ク ケ コ サ シ ス セ ソ タ チ ツ テ ト ナ ニ ヌ ネ ノ ハ ヒ フ ヘ ホ マ ミ ム メ モ ヤ ユ ヨ ラ リ ル レ ロ ワ ヲ ン ァ ィ ゥ ェ ォ ッ ャ ュ ョ ガ ギ グ ゲ ゴ ザ ジ ズ ゼ ゾ ダ ヂ ヅ デ ド バ ビ ブ ベ ボ パ ピ プ ペ ポ ー'.replaceAll(' ',''));

export const latinCharacters=Array.from('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890〜!?@#$%^&*()+÷×=[]|;:,./<>_-¥・「」、…♡♪↑↓→←○〒');
export const emojiPackages=[
 {id:'regular',label:'絵文字',base:0,extra:true},
 {id:'all-plus',label:'デコ文字（かなカナ／英数字）＋絵文字',base:265,extra:true},
 {id:'kana-plus',label:'デコ文字（かなカナ）＋絵文字',base:161,extra:true},
 {id:'latin-plus',label:'デコ文字（英数字）＋絵文字',base:104,extra:true},
 {id:'all',label:'デコ文字（かなカナ／英数字）',base:265,extra:false},
 {id:'kana',label:'デコ文字（かなカナ）',base:161,extra:false},
 {id:'latin',label:'デコ文字（英数字）',base:104,extra:false}
] as const;
export function emojiPackage(n:number){return emojiPackages.find(p=>p.extra?n>=p.base+8&&n<=p.base+40:n===p.base)??emojiPackages[0];}
export function emojiLabels(n:number){const p=emojiPackage(n);if(!p.base)return undefined;const chars=p.base===265?[...kanaCharacters,...latinCharacters]:p.base===161?kanaCharacters:latinCharacters;return [...chars,...Array.from({length:n-p.base},(_,i)=>'絵文字 '+(i+1))];}
