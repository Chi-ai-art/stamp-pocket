export type ProductKind='sticker'|'emoji';
export const formats={
 sticker:{label:'LINEスタンプ',noun:'スタンプ',counts:[8,16,24,32,40],width:370,height:320,margin:10,digits:2,main:true,zipMB:60,source:'https://creator.line.me/ja/guideline/sticker/'},
 emoji:{label:'LINE絵文字',noun:'絵文字',counts:[...Array.from({length:33},(_,i)=>i+8),161],width:180,height:180,margin:0,digits:3,main:false,zipMB:20,source:'https://creator.line.me/ja/guideline/emoji/'}
} as const;
export const validCount=(kind:ProductKind,n:number)=>(formats[kind].counts as readonly number[]).includes(n);

export const kanaCharacters=Array.from('あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわをんぁぃぅぇぉっゃゅょがぎぐげござじずぜぞだぢづでどばびぶべぼぱぴぷぺぽア イ ウ エ オ カ キ ク ケ コ サ シ ス セ ソ タ チ ツ テ ト ナ ニ ヌ ネ ノ ハ ヒ フ ヘ ホ マ ミ ム メ モ ヤ ユ ヨ ラ リ ル レ ロ ワ ヲ ン ァ ィ ゥ ェ ォ ッ ャ ュ ョ ガ ギ グ ゲ ゴ ザ ジ ズ ゼ ゾ ダ ヂ ヅ デ ド バ ビ ブ ベ ボ パ ピ プ ペ ポ ー'.replaceAll(' ',''));
