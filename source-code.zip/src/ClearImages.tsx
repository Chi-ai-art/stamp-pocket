import {useState} from 'react';
import type {Sticker} from './data/types';
export default function ClearImages({stickers,onDelete}:{stickers:Sticker[];onDelete:(ids:string[])=>void}){
 const [open,setOpen]=useState(false),[ids,setIds]=useState<string[]>([]);
 const chosen=ids.filter(id=>stickers.some(s=>s.id===id));
 return <section className="clear-images"><div className="clear-stock-row"><button className="text-button delete-button" disabled={!stickers.length} onClick={()=>onDelete(stickers.map(s=>s.id))}>全部まとめてクリア（{stickers.length}個）</button><button className="text-button delete-button" disabled={!stickers.length} aria-expanded={open} onClick={()=>setOpen(!open)}>選んだものをクリア</button></div>{open&&<div><p className="small">削除する画像にチェックを入れてください。</p><div className="clear-image-grid">{stickers.map((s,i)=><label key={s.id}><input type="checkbox" aria-label={`${i+1}番を削除対象にする`} checked={chosen.includes(s.id)} onChange={()=>setIds(old=>old.includes(s.id)?old.filter(id=>id!==s.id):[...old,s.id])}/><img src={s.image} alt={`${i+1}番`}/></label>)}</div><button className="secondary delete-button" disabled={!chosen.length} onClick={()=>{onDelete(chosen);}}>選んだ{chosen.length}個をクリア</button></div>}</section>;
}
