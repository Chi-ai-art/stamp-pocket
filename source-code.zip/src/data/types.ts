export type Accent = 'leaf' | 'peach' | 'butter';
export interface Sticker {id:string; original:string; image:string; selected:boolean; kept?:boolean; enhanced:boolean; name:string; width:number;height:number;}
export interface Draft {version:1;target:number;stickers:Sticker[];mainId:string;title:string;batchIds?:string[];savedAt?:number;}
export interface Sheet {src:string;name:string;width:number;height:number;}
