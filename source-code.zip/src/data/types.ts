export interface Placement {x:number;y:number;scale:number;}
export type Accent = 'leaf' | 'peach' | 'butter';
export interface Sticker {placement?:Placement;id:string; original:string; image:string; selected:boolean; kept?:boolean; enhanced:boolean; name:string; width:number;height:number;}
export interface Draft {version:1;kind?:import('../formats').ProductKind;target:number;stickers:Sticker[];mainId:string;tabId?:string;title:string;batchIds?:string[];savedAt?:number;}
export interface Sheet {src:string;name:string;width:number;height:number;}
