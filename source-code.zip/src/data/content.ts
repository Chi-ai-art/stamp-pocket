export const counts = [8,16,24,32,40] as const;
export const steps = [{label:'画像を入れる',short:'画像',hint:'写真から選んでスタート'},{label:'キープ・セット選択',short:'ストック',hint:'キープから今回使う画像を選ぶ'},{label:'確認・保存',short:'保存',hint:'あなたのセットが完成'}];
export const guide = [{title:'一覧画像を入れる',body:'透過済みPNGを入れて、1枚ずつ切り分けます。背景を消す機能はありません。'},{title:'良いものだけキープ',body:'気に入った仕上がりをストック。端末に自動保存され、続きから再開できます。'},{title:'そろったら、ひとまとめ',body:'ストックから使う画像を選び、種類に合った申請画像をZIP保存。キープは残ります。'}];
export const spec = {source:'https://creator.line.me/ja/guideline/sticker/',checked:'2026-09-07',width:370,height:320,main:[240,240],tab:[96,74],margin:10};
