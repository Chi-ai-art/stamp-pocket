export const counts = [8,16,24,32,40] as const;
export const steps = [{label:'画像を入れる',short:'画像',hint:'写真から選んでスタート'},{label:'キープ・ストック',short:'ストック',hint:'良いものを少しずつ集める'},{label:'確認・保存',short:'保存',hint:'あなたのセットが完成'}];
export const guide = [{title:'一覧画像を入れる',body:'整列した画像なら、まとめて切り抜き。別の画像からも追加できます。'},{title:'良いものだけキープ',body:'気に入った仕上がりをストック。端末に自動保存され、続きから再開できます。'},{title:'そろったら、ひとまとめ',body:'ストックから使う画像を選び、メイン・タブ画像と一緒にZIP保存。キープは残ります。'}];
export const spec = {source:'https://creator.line.me/ja/guideline/sticker/',checked:'2026-09-07',width:370,height:320,main:[240,240],tab:[96,74],margin:10};
