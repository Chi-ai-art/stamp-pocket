import {canvas,loadImage} from './imaging';

// White-on-white artwork has no unique color-only solution. This optional mode
// retains a small neighborhood around the artwork, including enclosed whites.
// It changes the alpha mask only: no generated or repainted foreground pixels.
export async function removeWhiteOutlineBackground(src:string,width=4,signal?:AbortSignal){
 const check=()=>{if(signal?.aborted)throw new DOMException('中止しました','AbortError');};
 const pause=async()=>{await new Promise(r=>setTimeout(r,0));check();};
 check();const im=await loadImage(src);check();
 const c=canvas(im.width,im.height),ctx=c.getContext('2d')!;ctx.drawImage(im,0,0);
 const frame=ctx.getImageData(0,0,c.width,c.height),d=frame.data,w=c.width,h=c.height,n=w*h;
 // Guard against using a white-outline preset on a colored background.
 let white=0,opaque=0;
 for(let j=0;j<128;j++)for(const p of [Math.round(j*(w-1)/127),(h-1)*w+Math.round(j*(w-1)/127),Math.round(j*(h-1)/127)*w,Math.round(j*(h-1)/127)*w+w-1]){
  const i=p*4;if(d[i+3]<240)continue;opaque++;if(Math.min(d[i],d[i+1],d[i+2])>=240)white++;
 }
 if(opaque&&white/opaque<.75)throw new Error('「白フチを残す」は白い背景の画像用です。通常の透過に切り替えてください。');
 let mask=new Uint8Array(n);const strong=new Uint8Array(n);let count=0;
 for(let p=0;p<n;p++){
  const i=p*4;if(d[i+3]<16)continue;
  const contrast=Math.max(255-d[i],255-d[i+1],255-d[i+2]);
  if(contrast>40){mask[p]=1;count++;}if(contrast>80)strong[p]=1;
 }
 if(!count)throw new Error('白い背景と絵を区別できませんでした。通常の透過か「ここだけ透過」をお試しください。');
 const dist=new Uint16Array(n);
 // Chamfer distance keeps each pass linear in image size, even for large sheets.
 async function morph(input:Uint8Array,radius:number,grow:boolean){
  const target=grow?1:0,limit=Math.round(radius*3);
  for(let p=0;p<n;p++)dist[p]=input[p]===target?0:60000;
  for(let y=0;y<h;y++){
   for(let x=0;x<w;x++){const p=y*w+x;let v=dist[p];
    if(!grow&&(x===0||y===0||x===w-1||y===h-1))v=Math.min(v,3);
    if(x)v=Math.min(v,dist[p-1]+3);if(y){v=Math.min(v,dist[p-w]+3);if(x)v=Math.min(v,dist[p-w-1]+4);if(x<w-1)v=Math.min(v,dist[p-w+1]+4);}dist[p]=v;
   }if(y%128===0)await pause();
  }
  for(let y=h-1;y>=0;y--){
   for(let x=w-1;x>=0;x--){const p=y*w+x;let v=dist[p];
    if(x<w-1)v=Math.min(v,dist[p+1]+3);if(y<h-1){v=Math.min(v,dist[p+w]+3);if(x)v=Math.min(v,dist[p+w-1]+4);if(x<w-1)v=Math.min(v,dist[p+w+1]+4);}dist[p]=v;
   }if(y%128===0)await pause();
  }
  const out=new Uint8Array(n);for(let p=0;p<n;p++)out[p]=grow?+(dist[p]<=limit):+(dist[p]>limit);return out;
 }
 // Suppress faint one-pixel shadow spurs, while retaining fine dark lettering.
 mask=await morph(await morph(mask,1,false),1,true);
 for(let p=0;p<n;p++)if(strong[p])mask[p]=1;
 const radius=Number.isFinite(width)?Math.max(1,Math.min(16,width)):4;
 mask=await morph(mask,radius,true);
 const outside=new Uint8Array(n),queue=new Int32Array(n);let head=0,tail=0;
 const add=(p:number)=>{if(!outside[p]&&!mask[p]){outside[p]=1;queue[tail++]=p;}};
 for(let x=0;x<w;x++){add(x);add((h-1)*w+x);}for(let y=0;y<h;y++){add(y*w);add(y*w+w-1);}
 while(head<tail){const p=queue[head++],x=p%w;if(x)add(p-1);if(x<w-1)add(p+1);if(p>=w)add(p-w);if(p<n-w)add(p+w);if(head%100000===0)await pause();}
 for(let p=0;p<n;p++)if(!outside[p])mask[p]=1;
 mask=await morph(await morph(mask,2,true),2,false);
 for(let y=0;y<h;y++){
  for(let x=0;x<w;x++){let coverage=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
   const xx=x+dx,yy=y+dy;if(xx>=0&&xx<w&&yy>=0&&yy<h)coverage+=mask[yy*w+xx]*(dx===0?2:1)*(dy===0?2:1);
  }const i=(y*w+x)*4;d[i+3]=Math.min(d[i+3],Math.round(255*coverage/16));}
  if(y%128===0)await pause();
 }
 check();ctx.putImageData(frame,0,0);return c.toDataURL('image/png');
}
