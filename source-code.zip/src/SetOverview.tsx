import {useState} from 'react';
import type {ReactNode} from 'react';
import type {Sticker} from './data/types';
import type {ProductKind} from './formats';
import {exportEntries} from './imaging';
export default function SetOverview({stickers,target,mainId,kind,render}:{stickers:Sticker[];target:number;mainId:string;kind:ProductKind;render:(s:Sticker,w:number,h:number)=>ReactNode}){
 const[dark,setDark]=useState(false);const entries=exportEntries(stickers,target,mainId,kind);const ordered=[...entries.filter(e=>e.name==='main.png'||e.name==='tab.png'),...entries.filter(e=>e.name!=='main.png'&&e.name!=='tab.png')];
 return <section className="set-overview" aria-label="まとめた見え方"><header className="overview-heading"><div><h3>まとめた見え方</h3><p className="small">メイン・タブと、セット全体のバランスを確認できます。</p></div><div className="overview-switch" role="group" aria-label="一覧の背景"><button aria-pressed={!dark} onClick={()=>setDark(false)}>白</button><button aria-pressed={dark} onClick={()=>setDark(true)}>黒</button></div></header><div className={'overview-sheet '+(dark?'overview-dark':'')}><div className="overview-grid">{ordered.map(e=><figure key={e.name} data-overview-name={e.name}><figcaption>{e.name.replace('.png','')}</figcaption><div className={'overview-image '+(e.name==='tab.png'?'overview-tab':'')}>{render(e.s,e.w,e.h)}</div></figure>)}</div></div><p className="small overview-note">並べ替え・位置調整・メイン画像の変更も反映されます。表示イメージです。</p></section>;
}
