import type {Draft} from './data/types';
async function db(){return new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open('stamp-pocket-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('drafts');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function writeDraft(value:Draft){const d=await db();return new Promise<void>((resolve,reject)=>{try{const t=d.transaction('drafts','readwrite');t.oncomplete=()=>{d.close();resolve();};t.onerror=()=>{d.close();reject(t.error);};t.onabort=()=>{d.close();reject(t.error||new Error('保存を完了できませんでした'));};try{t.objectStore('drafts').put(value,'current');}catch(e){t.abort();d.close();reject(e);}}catch(e){d.close();reject(e);}});}
// Serialize complete snapshots so a slower older save cannot overwrite a newer keep.
let pending:Promise<void>=Promise.resolve();
export function saveDraft(value:Draft){const next=pending.catch(()=>{}).then(()=>writeDraft(value));pending=next;return next;}
export async function getDraft(){const d=await db();return new Promise<Draft|undefined>((resolve,reject)=>{const t=d.transaction('drafts');const r=t.objectStore('drafts').get('current');r.onsuccess=()=>{d.close();resolve(r.result?.version===1?r.result:undefined);};r.onerror=()=>{d.close();reject(r.error);};});}
