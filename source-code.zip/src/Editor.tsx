import {useScrollLock} from './useScrollLock';
import PositionEditor from './PositionEditor';
import type {ProductKind} from './formats';
import type {Placement,Sticker} from './data/types';
import {useEffect,useState} from 'react';
import {X,Check,Sparkles} from 'lucide-react';
export default function Editor({sticker,onSave,onClose,kind='sticker',saveLabel}:{kind?:ProductKind;sticker:Sticker;onSave:(s:Sticker)=>void;onClose:()=>void;saveLabel?:string}){
 useScrollLock();
 const[placement,setPlacement]=useState<Placement>(sticker.placement??{x:0,y:0,scale:100}),[positioning,setPositioning]=useState(false),[up,setUp]=useState(sticker.enhanced);
 return <div className="modal-backdrop"><section className="editor modal" role="dialog" aria-modal="true" aria-label="画像の位置・大きさを調整" onKeyDown={e=>{if(e.key==='Escape')onClose();if(e.key==='Tab'){const ns=Array.from(e.currentTarget.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled])'));if(e.shiftKey&&document.activeElement===ns[0]){e.preventDefault();ns.at(-1)?.focus();}else if(!e.shiftKey&&document.activeElement===ns.at(-1)){e.preventDefault();ns[0]?.focus();}}}}>
 <header className="modal-head"><div><span className="eyebrow">位置と大きさを、整えよう</span><h2>{sticker.name}</h2></div><button autoFocus className="icon-btn" onClick={onClose} aria-label="保存せず閉じる"><X/></button></header>
 {!positioning&&<div className="edit-stage dark"><img src={sticker.image} alt={sticker.name}/></div>}
 <div className="editor-scroll"><button className="secondary full" onClick={()=>setPositioning(!positioning)}>{positioning?'位置の調整を閉じる':'上下左右・中央に位置調整'}</button>{positioning&&<PositionEditor sticker={{...sticker,enhanced:up}} kind={kind} value={placement} onChange={setPlacement}/>}
 <p className="small">透明部分はそのまま保持します。背景が残っている場合は、透過済みの元画像を追加してください。</p>
 <div className="enhance-box"><label className="check-label"><input type="checkbox" checked={up} onChange={e=>setUp(e.target.checked)}/><Sparkles size={18}/><strong>この画像だけ、くっきり補正</strong></label><p className="small">2倍拡大＋輪郭補正。位置調整画面で仕上がりを確認できます。</p></div></div>
 <footer className="modal-foot"><button className="secondary" onClick={onClose}>キャンセル</button><button className="primary" onClick={()=>onSave({...sticker,enhanced:up,placement})}><Check size={18}/>{saveLabel??(sticker.kept?'キープを更新':'この仕上がりをキープ')}</button></footer></section></div>;
}

