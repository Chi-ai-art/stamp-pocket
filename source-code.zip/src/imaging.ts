import {formats,validCount} from './formats';
import type {ProductKind} from './formats';
import type {Sticker} from './data/types';
import JSZip from 'jszip';
export const canvas=(w:number,h:number)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
const uniqueId=()=>typeof crypto.randomUUID==='function'?crypto.randomUUID():Array.from(crypto.getRandomValues(new Uint32Array(4)),v=>v.toString(16)).join('-');
export const loadImage=(src:string)=>new Promise<HTMLImageElement>((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=()=>reject(new Error('画像を読み込めませんでした。PNG・JPEG・WebPの画像を選んでください。'));i.src=src;});
const blob=(c:HTMLCanvasElement)=>new Promise<Blob>((resolve,reject)=>c.toBlob(b=>b?resolve(b):reject(new Error('PNGへの変換に失敗しました。')),'image/png'));
const dataUrl=(value:Blob)=>new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>typeof reader.result==='string'?resolve(reader.result):reject(new Error('画像の変換に失敗しました。'));reader.onerror=()=>reject(new Error('画像の変換に失敗しました。'));reader.readAsDataURL(value);});
const nextFrame=()=>new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));
export async function suggestCuts(src:string,cols:number,rows:number){const im=await loadImage(src),scale=Math.min(1,1200/im.width,1200/im.height),w=Math.round(im.width*scale),h=Math.round(im.height*scale),c=canvas(w,h),ctx=c.getContext('2d')!;ctx.drawImage(im,0,0,w,h);const d=ctx.getImageData(0,0,w,h).data,xScores=new Float64Array(w),yScores=new Float64Array(h);const corners=[0,w-1,w*(h-1),w*h-1];const bg=[0,1,2].map(k=>corners.map(p=>d[p*4+k]).sort((a,b)=>a-b)[2]);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=(y*w+x)*4;const delta=Math.max(Math.abs(d[p]-bg[0]),Math.abs(d[p+1]-bg[1]),Math.abs(d[p+2]-bg[2]));if(d[p+3]>20&&delta>20){xScores[x]++;yScores[y]++;}}
 const cuts=(scores:Float64Array,n:number)=>{const size=scores.length,out=[0];for(let i=1;i<n;i++){const ideal=size*i/n,range=size/n*.38;let best=Math.round(ideal),cost=Infinity;for(let j=Math.max(3,Math.floor(ideal-range));j<Math.min(size-3,ideal+range);j++){let score=0;for(let k=-3;k<=3;k++)score+=scores[j+k];score+=Math.abs(j-ideal)/size*.1;if(score<cost){cost=score;best=j;}}out.push(best/size);}return [...out,1];};return {xs:cuts(xScores,cols),ys:cuts(yScores,rows)};}
export async function readFile(file:File){
 if(file.size>30*1024*1024)throw new Error('画像は1枚30MB以下にしてください。');
 const url=URL.createObjectURL(file);
 try{
  const i=await loadImage(url),pixels=i.width*i.height;
  if(pixels>60000000)throw new Error('画像がとても大きいため読み込めません。6000万画素以下に縮小してから追加してください。');
  const scale=Math.min(1,4096/Math.max(i.width,i.height),Math.sqrt(9000000/pixels));
  if(scale===1)return{src:await dataUrl(file),width:i.width,height:i.height,name:file.name};
  const width=Math.max(1,Math.round(i.width*scale)),height=Math.max(1,Math.round(i.height*scale));
  await nextFrame();
  const c=canvas(width,height),ctx=c.getContext('2d')!;
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(i,0,0,width,height);
  return{src:await dataUrl(await blob(c)),width,height,name:file.name};
 }finally{URL.revokeObjectURL(url);}
}
export async function splitSheet(src:string,xs:number[],ys:number[],onProgress:(p:number)=>void){const im=await loadImage(src);const result:Sticker[]=[];const total=(xs.length-1)*(ys.length-1);
 for(let y=0;y<ys.length-1;y++)for(let x=0;x<xs.length-1;x++){const l=Math.round(xs[x]*im.width),t=Math.round(ys[y]*im.height),r=Math.round(xs[x+1]*im.width),b=Math.round(ys[y+1]*im.height);const c=canvas(r-l,b-t);c.getContext('2d')!.drawImage(im,l,t,r-l,b-t,0,0,r-l,b-t);const original=c.toDataURL();result.push({id:uniqueId(),name:`スタンプ ${result.length+1}`,original,image:original,selected:false,enhanced:false,width:c.width,height:c.height});onProgress(result.length/total);await new Promise(r=>setTimeout(r,0));}return result;}
export function bounds(c:HTMLCanvasElement){const{data:d}=c.getContext('2d')!.getImageData(0,0,c.width,c.height);let l=c.width,t=c.height,r=-1,b=-1;for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(d[(y*c.width+x)*4+3]>8){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}if(r<0)throw new Error('絵がすべて透明になっています。元の画像を確認して、追加し直してください。');return {l,t,w:r-l+1,h:b-t+1};}
export function enhance(c:HTMLCanvasElement){const out=canvas(c.width*2,c.height*2),ctx=out.getContext('2d')!;ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(c,0,0,out.width,out.height);const im=ctx.getImageData(0,0,out.width,out.height),s=new Uint8ClampedArray(im.data),d=im.data,w=out.width;
 for(let y=1;y<out.height-1;y++)for(let x=1;x<w-1;x++){const p=(y*w+x)*4;if(s[p+3]<250||s[p-4+3]<250||s[p+4+3]<250||s[p-w*4+3]<250||s[p+w*4+3]<250)continue;for(let k=0;k<3;k++){const blur=(s[p-4+k]+s[p+4+k]+s[p-w*4+k]+s[p+w*4+k])/4;d[p+k]=s[p+k]+.45*(s[p+k]-blur);}}
 ctx.putImageData(im,0,0);return out;}
export async function fitted(sticker:Sticker,w=370,h=320,margin=(w===370?10:4),upscale=false){const i=await loadImage(sticker.image),raw=canvas(i.width,i.height);raw.getContext('2d')!.drawImage(i,0,0);const b=bounds(raw),cropped=canvas(b.w,b.h);cropped.getContext('2d')!.drawImage(raw,b.l,b.t,b.w,b.h,0,0,b.w,b.h);const source=sticker.enhanced?enhance(cropped):cropped;const out=canvas(w,h),ctx=out.getContext('2d')!;const placement=sticker.placement??{x:0,y:0,scale:100};const clamp=(v:number,min:number,max:number)=>Number.isFinite(v)?Math.max(min,Math.min(max,v)):0;const scale=Math.min((w-2*margin)/source.width,(h-2*margin)/source.height,upscale?Infinity:1)*clamp(placement.scale,40,100)/100;const dw=Math.round(source.width*scale),dh=Math.round(source.height*scale);ctx.imageSmoothingQuality='high';ctx.drawImage(source,Math.floor(margin+(w-2*margin-dw)*(clamp(placement.x,-100,100)+100)/200),Math.floor(margin+(h-2*margin-dh)*(clamp(placement.y,-100,100)+100)/200),dw,dh);return out;}
export function exportEntries(stickers:Sticker[],target:number,mainId:string,kind:ProductKind,tabId=mainId){const f=formats[kind],selected=stickers.filter(s=>s.selected);if(!validCount(kind,target)||selected.length!==target)throw new Error('セットの個数を確認してください。');const main=selected.find(s=>s.id===mainId)||selected[0];return [...selected.map((s,i)=>({s,name:String(i+1).padStart(f.digits,'0')+'.png',w:f.width,h:f.height})),...(f.main?[{s:main,name:'main.png',w:240,h:240}]:[]),{s:selected.find(s=>s.id===tabId)||selected[0],name:'tab.png',w:96,h:74}];}
export async function exportPng(e:ReturnType<typeof exportEntries>[number],kind:ProductKind){const b=await blob(await fitted(e.s,e.w,e.h,kind==='emoji'?0:(e.w===370?10:4),kind==='emoji'));if(b.size>1024*1024)throw new Error(e.name+' が1MBを超えています。');return b;}
export async function makeZip(stickers:Sticker[],target:number,mainId:string,onProgress:(p:number)=>void,kind:ProductKind='sticker',tabId=mainId){const zip=new JSZip(),entries=exportEntries(stickers,target,mainId,kind,tabId);for(let i=0;i<entries.length;i++){zip.file(entries[i].name,await exportPng(entries[i],kind));onProgress((i+1)/entries.length*.8);}const out=await zip.generateAsync({type:'blob',compression:'DEFLATE'},m=>onProgress(.8+m.percent/500));if(out.size>formats[kind].zipMB*1024*1024)throw new Error('ZIPの容量が上限を超えています。');return out;}
