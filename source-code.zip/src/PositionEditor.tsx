import {useEffect,useState} from 'react';
import {ArrowUp,ArrowDown,ArrowLeft,ArrowRight} from 'lucide-react';
import {fitted} from './imaging';
import {formats} from './formats';
import type {ProductKind} from './formats';
import type {Sticker,Placement} from './data/types';
export default function PositionEditor({sticker,kind,value,onChange}:{sticker:Sticker;kind:ProductKind;value:Placement;onChange:(v:Placement)=>void}){
 const[url,setUrl]=useState('');const f=formats[kind];
 useEffect(()=>{let alive=true;fitted({...sticker,placement:value},f.width,f.height,f.margin,kind==='emoji').then(c=>{if(alive)setUrl(c.toDataURL());}).catch(()=>{if(alive)setUrl('');});return()=>{alive=false;};},[sticker.image,sticker.enhanced,kind,value]);
 const move=(x:number,y:number)=>onChange({...value,x:Math.max(-100,Math.min(100,value.x+x)),y:Math.max(-100,Math.min(100,value.y+y))});
 return <section className="position-editor"><strong>申請画像の位置と大きさ</strong><p className="small">枠が保存される画像の範囲です。絵が切れない範囲で動かせます。動く余地が少ないときは、大きさを下げてください。</p><div className="position-preview checker" style={{aspectRatio:`${f.width}/${f.height}`}}>{url&&<img src={url} alt="位置調整後の申請画像"/>}<span className="center-cross"/></div><p className="small">{f.label} ／ {f.width} × {f.height}px</p><div className="position-buttons"><button className="secondary" aria-label="画像を左へ" onClick={()=>move(-10,0)}><ArrowLeft size={18}/></button><button className="secondary" aria-label="画像を上へ" onClick={()=>move(0,-10)}><ArrowUp size={18}/></button><button className="secondary" onClick={()=>onChange({...value,x:0,y:0})}>中央に戻す</button><button className="secondary" aria-label="画像を下へ" onClick={()=>move(0,10)}><ArrowDown size={18}/></button><button className="secondary" aria-label="画像を右へ" onClick={()=>move(10,0)}><ArrowRight size={18}/></button></div>{(['x','y','scale'] as const).map(key=><label className="range-label" key={key}>{key==='x'?'左右':key==='y'?'上下':'大きさ'}<input aria-label={'画像の'+(key==='x'?'左右':key==='y'?'上下':'大きさ')} type="range" min={key==='scale'?40:-100} max="100" step="1" value={value[key]} onChange={e=>onChange({...value,[key]:+e.target.value})}/><span>{value[key]}{key==='scale'?'%':''}</span></label>)}<p className="small">この位置は本体・メイン・タブの書き出しに反映されます。十字線は保存されません。</p></section>;
}

